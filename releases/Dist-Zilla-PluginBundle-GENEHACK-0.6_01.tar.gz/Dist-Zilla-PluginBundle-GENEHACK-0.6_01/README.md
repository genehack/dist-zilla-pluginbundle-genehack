# NAME

Dist::Zilla::PluginBundle::GENEHACK - BeLike::GENEHACK when you zilla your dist

# VERSION

[![CPAN version](https://badge.fury.io/pl/Git-Wrapper.svg)](http://badge.fury.io/pl/Git-Wrapper)

# INFO

See
[https://metacpan.org/pod/Dist::Zilla::PluginBundle::GENEHACK](Dist::Zilla::PluginBundle::GENEHACK)
on MetaCPAN.

