# NAME

Dist::Zilla::PluginBundle::GENEHACK - BeLike::GENEHACK when you zilla your dist

# VERSION

[![CPAN version](https://badge.fury.io/pl/Dist-Zilla-PluginBundle-GENEHACK.svg)](http://badge.fury.io/pl/Dist-Zilla-PluginBundle-GENEHACK)

# INFO

See
[https://metacpan.org/pod/Dist::Zilla::PluginBundle::GENEHACK](Dist::Zilla::PluginBundle::GENEHACK)
on MetaCPAN.

